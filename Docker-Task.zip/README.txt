Commands to build the image and run as containers in docker

cd C:\Docker-task\Apache
docker build -t <Image_name> .
Ex:- docker build -t apache .
docker run -d --name <container_name> -p 80:80 <Image_name> 
Ex:- docker run -d --name apache -p 80:80 apache


cd C:\Docker-task\IIS
docker build -t <Image_name> .
Ex:- docker build -t iis .
docker run -d --name <container_name> -p 8080:8080 <Image_name>
docker run -d --name iis -p 8080:8080 iis


The website content gets blocked when button is clicked. Allow the blocked content to make the website displayed on the page on button click